Array=csvread('sample nonLive data pitch angle.csv',0,0);
col1 = Array(:, 1);
col2 = Array(:, 2);
plot(col1*10^-3, col2)