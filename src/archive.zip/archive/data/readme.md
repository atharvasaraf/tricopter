Contains data collected through,
1)usb cable
2)Telemetry
for analysing the quadcopters response
