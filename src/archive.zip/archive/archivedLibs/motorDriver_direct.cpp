#include"Arduino.h"
#include"variables.cpp"
short shitCounter = 0;

//int motorWrite();
int motorSetup();

//Motor pins
#define esc1 5
#define esc2 6
#define esc3 9
#define esc4 10
//Changing this wont do a thing DONT FORGET THIS


int motorSetup()
{
 // Serial.println("motor Setup");
    // MOTOR SIDE
  //end points depends on the esc calibration
  DDRD = DDRD | B01100000;//pin 5,6
  DDRB = DDRB | B00000110;//pin 10,9

  PORTD &= B11011111;//pin 5 to zero
  PORTD &= B10111111;//pin 6
  PORTB &= B11111101;//pin 9
  PORTB &= B11111011;//pin 10 incase some cup happened

for(int i=0;i<1000;i++)//wait 2 sec
  {  delayMicroseconds(3000);
       PORTD = PORTD | B01100000;// Made high
       PORTB = PORTB | B00000110;// esc Made high
     delayMicroseconds(1000);//1ms pulse
        PORTD &= B11011111;//pin 5 to zero
        PORTD &= B10111111;//pin 6
        PORTB &= B11111101;//pin 9
        PORTB &= B11111011;//pin 10 incase some cup happened
  }
    //Serial.println("Motor setup don");

  return 0;
}

/////////////////////////////////////////////////////////////////////////////
//                                  MotorWrite
////////////////////////////////////////////////////////////////////////////
//This basically writes into esc after putting a final foolproof mechanism(Thrust limiter for the Esc)
#define max_throttle 750

int motorWriter1()
{
   // Serial.println("44 \n");

  //noInterrupts();// to avoid inputs from messing with esc pulses
  //DONT CALL SERIAL PRINT WHEN INTERRUPTS ARE DISABLED EVER
   //  Serial.println(freeMemory());
   // Serial.println(F("45 \n"));
  if (state.thrust1 > lowerLimit + max_throttle) { state.thrust1 = lowerLimit + max_throttle;}
                                                                //shitCounter++;}
  if (state.thrust2 > lowerLimit + max_throttle) { state.thrust2 = lowerLimit + max_throttle;}
                                                                //shitCounter++;}
  if (state.thrust3 > lowerLimit + max_throttle) {state.thrust3 = lowerLimit + max_throttle;}
                                                               //shitCounter++;}
  if (state.thrust4 > lowerLimit + max_throttle) {state.thrust4 = lowerLimit + max_throttle;}
                                                               // shitCounter++;}

  //if(shitCounter>=100) dead();
  // Serial.println(freeMemory());
  //Serial.println(F("potato46"));

  //noInterrupts();//NO BUllshits after this lineTAKE LITE-DOESNOT SEEM TO WORK
  unsigned int startTime=micros();
  unsigned int endTimeEsc1=state.thrust1+startTime;
  unsigned int endTimeEsc2=state.thrust2+startTime;
  unsigned int endTimeEsc3=state.thrust3+startTime;
  unsigned int endTimeEsc4=state.thrust4+startTime;
  unsigned int endTimeMax=startTime+2500;
  unsigned int currTime=startTime;
  PORTD = PORTD | B01100000;// Made high
  PORTB = PORTB | B00000110;// esc Made high
  while(currTime<endTimeMax)
  {   currTime=micros();
      if(currTime>endTimeEsc1) PORTD &= B11011111;//pin 5
      if(currTime>endTimeEsc2) PORTD &= B10111111;//6th pin
      if(currTime>endTimeEsc3) PORTB &= B11111101;//9 pin
      if(currTime>endTimeEsc4) PORTB &= B11111011;//pin 10
  }
  PORTD &= B11011111;//pin 5
  PORTD &= B10111111;//pin 6
  PORTB &= B11111101;//pin 9
  PORTB &= B11111011;//pin 10 incase some cup happened
  //interrupts();// To again enable interrupts TAKE LITE-DOESNOT SEEM TO WORK
  //Serial.println("done motorPrint");
  return 0;
}
