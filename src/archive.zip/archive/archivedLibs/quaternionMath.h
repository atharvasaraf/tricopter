


float theta = 0, thetaDerivative = 0, thetaIntegral = 0;
float previousTheta = 0;

int quaternionMath(Quaternion q);
//////////////////////////////////////////////////////////////////
//                  QUATERNION TO ANGLES AND AXIS
//////////////////////////////////////////////////////////////////
//This function is meant to get the vector about which one should turn the quadcopter from the quaternion given by the mpu6050
//torque calculations are done in body frame because its easy to compute them by fixing the axes limbs along the quad limbs (or 45 deg to them)
//It should matter whether we do in earth or body frome, however the 3 numbers given by toque equation must be balanced with the 3 numbers given as the quaternion vector 
//So we are converting the 3 numbers representing quaternion vector to the quadopters frome of reference:)
float w = 0, x = 0, y = 0, z = 0;
float vx = 0, vy = 0, vz = 0;
//float theta=0;
float axisVector[3] = {0, 0, 0};

int quaternionMath(Quaternion q)
{
  w = q.w;
  x = q.x;
  y = q.y;
  z = q.z;
  theta = 2 * acos(w);
  vx = x / sin(theta / 2);
  vy = y / sin(theta / 2);
  vz = z / sin(theta / 2);
  axisVector[1] = (x * (4 * pow(vx, 4) + 4 * pow(vx, 2) * pow(vy, 2) + 4 * pow(vx, 2) * pow(vz, 2) + 4 * pow(vx, 2) * pow(w, 2) - 4 * pow(vx, 2) - 2 * pow(vy, 2) - 2 * pow(vz, 2) + 1)) / (4 * pow(vx, 4) + 8 * pow(vx, 2) * pow(vy, 2) + 8 * pow(vx, 2) * pow(vz, 2) + 4 * pow(vx, 2) * pow(w, 2) - 4 * pow(vx, 2) + 4 * pow(vy, 4) + 8 * pow(vy, 2) * pow(vz, 2) + 4 * pow(vy, 2) * pow(w, 2) - 4 * pow(vy, 2) + 4 * pow(vz, 4) + 4 * pow(vz, 2) * pow(w, 2) - 4 * pow(vz, 2) + 1) + (2 * y * (2 * pow(vx, 3) * vy + 2 * vx * pow(vy, 3) + 2 * vx * vy * pow(vz, 2) + 2 * vx * vy * pow(w, 2) - vx * vy + vz * w)) / (4 * pow(vx, 4) + 8 * pow(vx, 2) * pow(vy, 2) + 8 * pow(vx, 2) * pow(vz, 2) + 4 * pow(vx, 2) * pow(w, 2) - 4 * pow(vx, 2) + 4 * pow(vy, 4) + 8 * pow(vy, 2) * pow(vz, 2) + 4 * pow(vy, 2) * pow(w, 2) - 4 * pow(vy, 2) + 4 * pow(vz, 4) + 4 * pow(vz, 2) * pow(w, 2) - 4 * pow(vz, 2) + 1) + (2 * z * (2 * pow(vx, 3) * vz + 2 * vx * pow(vy, 2) * vz + 2 * vx * pow(vz, 3) + 2 * vx * vz * pow(w, 2) - vx * vz - vy * w)) / (4 * pow(vx, 4) + 8 * pow(vx, 2) * pow(vy, 2) + 8 * pow(vx, 2) * pow(vz, 2) + 4 * pow(vx, 2) * pow(w, 2) - 4 * pow(vx, 2) + 4 * pow(vy, 4) + 8 * pow(vy, 2) * pow(vz, 2) + 4 * pow(vy, 2) * pow(w, 2) - 4 * pow(vy, 2) + 4 * pow(vz, 4) + 4 * pow(vz, 2) * pow(w, 2) - 4 * pow(vz, 2) + 1);
  axisVector[2] = (y * (4 * pow(vx, 2) * pow(vy, 2) - 2 * pow(vx, 2) + 4 * pow(vy, 4) + 4 * pow(vy, 2) * pow(vz, 2) + 4 * pow(vy, 2) * pow(w, 2) - 4 * pow(vy, 2) - 2 * pow(vz, 2) + 1)) / (4 * pow(vx, 4) + 8 * pow(vx, 2) * pow(vy, 2) + 8 * pow(vx, 2) * pow(vz, 2) + 4 * pow(vx, 2) * pow(w, 2) - 4 * pow(vx, 2) + 4 * pow(vy, 4) + 8 * pow(vy, 2) * pow(vz, 2) + 4 * pow(vy, 2) * pow(w, 2) - 4 * pow(vy, 2) + 4 * pow(vz, 4) + 4 * pow(vz, 2) * pow(w, 2) - 4 * pow(vz, 2) + 1) + (2 * x * (2 * pow(vx, 3) * vy + 2 * vx * pow(vy, 3) + 2 * vx * vy * pow(vz, 2) + 2 * vx * vy * pow(w, 2) - vx * vy - vz * w)) / (4 * pow(vx, 4) + 8 * pow(vx, 2) * pow(vy, 2) + 8 * pow(vx, 2) * pow(vz, 2) + 4 * pow(vx, 2) * pow(w, 2) - 4 * pow(vx, 2) + 4 * pow(vy, 4) + 8 * pow(vy, 2) * pow(vz, 2) + 4 * pow(vy, 2) * pow(w, 2) - 4 * pow(vy, 2) + 4 * pow(vz, 4) + 4 * pow(vz, 2) * pow(w, 2) - 4 * pow(vz, 2) + 1) + (2 * z * (2 * pow(vx, 2) * vy * vz + vx * w + 2 * pow(vy, 3) * vz + 2 * vy * pow(vz, 3) + 2 * vy * vz * pow(w, 2) - vy * vz)) / (4 * pow(vx, 4) + 8 * pow(vx, 2) * pow(vy, 2) + 8 * pow(vx, 2) * pow(vz, 2) + 4 * pow(vx, 2) * pow(w, 2) - 4 * pow(vx, 2) + 4 * pow(vy, 4) + 8 * pow(vy, 2) * pow(vz, 2) + 4 * pow(vy, 2) * pow(w, 2) - 4 * pow(vy, 2) + 4 * pow(vz, 4) + 4 * pow(vz, 2) * pow(w, 2) - 4 * pow(vz, 2) + 1);
  axisVector[3] = (z * (4 * pow(vx, 2) * pow(vz, 2) - 2 * pow(vx, 2) + 4 * pow(vy, 2) * pow(vz, 2) - 2 * pow(vy, 2) + 4 * pow(vz, 4) + 4 * pow(vz, 2) * pow(w, 2) - 4 * pow(vz, 2) + 1)) / (4 * pow(vx, 4) + 8 * pow(vx, 2) * pow(vy, 2) + 8 * pow(vx, 2) * pow(vz, 2) + 4 * pow(vx, 2) * pow(w, 2) - 4 * pow(vx, 2) + 4 * pow(vy, 4) + 8 * pow(vy, 2) * pow(vz, 2) + 4 * pow(vy, 2) * pow(w, 2) - 4 * pow(vy, 2) + 4 * pow(vz, 4) + 4 * pow(vz, 2) * pow(w, 2) - 4 * pow(vz, 2) + 1) + (2 * x * (2 * pow(vx, 3) * vz + 2 * vx * pow(vy, 2) * vz + 2 * vx * pow(vz, 3) + 2 * vx * vz * pow(w, 2) - vx * vz + vy * w)) / (4 * pow(vx, 4) + 8 * pow(vx, 2) * pow(vy, 2) + 8 * pow(vx, 2) * pow(vz, 2) + 4 * pow(vx, 2) * pow(w, 2) - 4 * pow(vx, 2) + 4 * pow(vy, 4) + 8 * pow(vy, 2) * pow(vz, 2) + 4 * pow(vy, 2) * pow(w, 2) - 4 * pow(vy, 2) + 4 * pow(vz, 4) + 4 * pow(vz, 2) * pow(w, 2) - 4 * pow(vz, 2) + 1) + (2 * y * (2 * pow(vx, 2) * vy * vz - vx * w + 2 * pow(vy, 3) * vz + 2 * vy * pow(vz, 3) + 2 * vy * vz * pow(w, 2) - vy * vz)) / (4 * pow(vx, 4) + 8 * pow(vx, 2) * pow(vy, 2) + 8 * pow(vx, 2) * pow(vz, 2) + 4 * pow(vx, 2) * pow(w, 2) - 4 * pow(vx, 2) + 4 * pow(vy, 4) + 8 * pow(vy, 2) * pow(vz, 2) + 4 * pow(vy, 2) * pow(w, 2) - 4 * pow(vy, 2) + 4 * pow(vz, 4) + 4 * pow(vz, 2) * pow(w, 2) - 4 * pow(vz, 2) + 1);
  return 0;
}

