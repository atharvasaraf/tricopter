
int thrustCalculator();
float fMean = 0;
float  thrust1 = 0, thrust2 = 0, thrust3 = 0, thrust4 = 00;
long now = 0, previousMicros = 0;

/////////////////////////////////////////////////////////////////////////////
//                              THRUST CALCULATOR
/////////////////////////////////////////////////////////////////////////////
//float kTau = 1.63; // From prop data
float kTau = 1.0; // prop data value not enough. decrese this to incresse yaw correction

float l = 0.23; //half Length of arm
const short lowerLimitOfOperation = 70;
float thrustIntegral_1=0;
float thrustIntegral_2=0;
float thrustIntegral_3=0;
float thrustIntegral_4=0;

float thrustDerivative_1=0;
float thrustDerivative_2=0;
float thrustDerivative_3=0;
float thrustDerivative_4=0;

float previousThrust_1=0;
float previousThrust_2=0;
float previousThrust_3=0;
float previousThrust_4=0;


//int thrust1=0,thrust2=0,thrust3=0,thrust4=00;
int thrustCalculator()
{

  //This calculates the Thrust to be given to motors in terms of Pulse width in microsecs
  thrust1 = fMean - (kp * theta ) / 4 * (-axisVector[3] / kTau - axisVector[2] / (l) - axisVector[1] / (l));
  thrust2 = fMean - (kp * theta ) / 4 * (-axisVector[3] / kTau + axisVector[2] / (l) + axisVector[1] / (l));
  thrust3 = fMean - (kp * theta ) / 4 * (+axisVector[3] / kTau - axisVector[2] / (l) + axisVector[1] / (l));
  thrust4 = fMean - (kp * theta ) / 4 * (+axisVector[3] / kTau + axisVector[2] / (l) - axisVector[1] / (l));
// thetaIntegral and thetaDerivative variables are deprecated now.

   if ( (now - previousMicros) > 3000 )//BLUNDER. if loop time is less then 10 it will never be invoken
  {
      thrustDerivative_1 = (thrust1 - previousThrust_1) / kp*kd*(now - previousMicros) * 1000000.0;
        thrustDerivative_2 = (thrust2 - previousThrust_2) /kp*kd* (now - previousMicros) * 1000000.0;
             thrustDerivative_3 = (thrust3 - previousThrust_3) /kp* kd*(now - previousMicros) * 1000000.0;
                  thrustDerivative_4 = (thrust4 - previousThrust_4) /kp* kd*(now - previousMicros) * 1000000.0;
                  
      previousThrust_1=thrust1;
      previousThrust_2=thrust2;
      previousThrust_3=thrust3;
      previousThrust_4=thrust4;
      
      thrustIntegral_1 = thrustIntegral_1 + (thrust1-fMean)/kp * ki*(now - previousMicros) * 0.000001;
            thrustIntegral_2 = thrustIntegral_2 + (thrust2-fMean)/kp * ki* (now - previousMicros) * 0.000001;
                  thrustIntegral_3 = thrustIntegral_3 + (thrust3-fMean)/kp * ki* (now - previousMicros) * 0.000001;
                        thrustIntegral_4 = thrustIntegral_4 + (thrust4-fMean)/kp * ki* (now - previousMicros) * 0.000001;
      
      thrust1=thrust1+thrustIntegral_1+thrustDerivative_1;
      thrust2=thrust2+thrustIntegral_2+thrustDerivative_2;
      thrust3=thrust3+thrustIntegral_3+thrustDerivative_3;
      thrust4=thrust4+thrustIntegral_4+thrustDerivative_4;
      previousMicros = now;   
      
       
  }
//Integral and Derivative correction.



//  rollInput=(pulseIn(channel_1,HIGH)-meanInput_ch1)*controlInputGain;
//  pitchInput=(pulseIn(channel_2,HIGH)-meanInput_ch2)*controlInputGain;
//  yawInput=(pulseIn(channel_4,HIGH)-meanInput_ch4)*controlInputGain;
//Serial.print("\t");
//Serial.print(rollInput);
//Serial.print("\t");
//  

  //Please this line may look long and bullshit. But dont ever attempt to shorten it(especially anil). 
  //Because C has some dumb conversion rules from floating to integer and it wont work properly for negative numbers.
  rollInput=r_input_signal[1-1]*controlInputGain-meanInput_ch1*controlInputGain;
  pitchInput=r_input_signal[2-1]*controlInputGain-meanInput_ch2*controlInputGain;
  yawInput=r_input_signal[4-1]*controlInputGain-meanInput_ch4*controlInputGain;
  yawInput=yawInput*10;

  thrust1=thrust1-rollInput-pitchInput+yawInput;
  thrust2=thrust2+rollInput+pitchInput+yawInput;
  thrust3=thrust3+rollInput-pitchInput-yawInput;
  thrust4=thrust4-rollInput+pitchInput-yawInput;
  
  if (fMean < lowerLimit + 25) {
    thrust1 = 0;  //to stop the rotors below some throttle input
    thrust2 = 0;
    thrust3 = 0;
    thrust4 = 0;
    thetaDerivative = 0;
    thetaIntegral = 0;
  }
  else {
    if (thrust1 < lowerLimit + lowerLimitOfOperation) {
      thrust1 = lowerLimit + lowerLimitOfOperation; // This is to prevent Motors from stopping when the quad is stabilizing. If it stops it will take more time to gain back speed. So let this be a sort of minimum speed.
    }
    if (thrust2 < lowerLimit + lowerLimitOfOperation) {
      thrust2 = lowerLimit + lowerLimitOfOperation;
    }
    if (thrust3 < lowerLimit + lowerLimitOfOperation) {
      thrust3 = lowerLimit + lowerLimitOfOperation;
    }
    if (thrust4 < lowerLimit + lowerLimitOfOperation) {
      thrust4 = lowerLimit + lowerLimitOfOperation;
    }
  }
  return 0;
}

